from .kettle import Kettle
from .router import Router
from .fridge import Fridge
from .power_supply import PowerSupply
